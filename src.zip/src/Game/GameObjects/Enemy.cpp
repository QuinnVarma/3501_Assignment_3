#include "Enemy.h"

Enemy::Enemy(float radius) : GameObject() {
}
