#pragma once

#include "ofMain.h"
#include "../GameObject.h"

class Collectable : public GameObject{

    
};
